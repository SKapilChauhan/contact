$(document).ready(function(){
	
	$("#moredetail").click(function(){
		//$("#para").toggle();
		//$("#colChange").removeClass("colorgreen");
		//$("#colChange").removeClass("color1");
		var heading =  "Business Solutions";
		var para = "Lorem ipsum is the most popular form of dummy content or placeholder text.";
		$("#head").html(heading);
		$("#parm").html(para);
		var data = [
			{
				name : "tushar",
				age : 25,
				mobile : 999965485,
				email : "tushar@gmail.com"
			},
			{
				name : "jatin",
				age : 35,
				mobile : 9854765485,
				email : "jatin@gmail.com"
			},
			{
				name : "sonu",
				age : 21,
				mobile : 9854747854,
				email : "sonu@gmail.com"
			},
			{
				name : "Monu",
				age : 27,
				mobile : 9855557854,
				email : "monu@gmail.com"
			}
		];	
		
		for(var i=0; i < data.length; i++){
			var el = document.createElement('div');
			el.setAttribute("class", "col-lg-3 col-md-6");
			
			var elbox = document.createElement('div');
			elbox.setAttribute("class", "box");
			
			var h2 = document.createElement('h2');
			h2.innerHTML = data[i].name;
			
			elbox.appendChild(h2);
			
			var para = document.createElement('p');
			para.innerHTML = "Email: " + data[i].email;
			elbox.appendChild(para);
			
			var para2 = document.createElement('p');
			para2.innerHTML = "Age: " + data[i].age;
			elbox.appendChild(para2);
			
			el.appendChild(elbox);
			var mainel = document.getElementById('databind');
			mainel.appendChild(el);
			
			console.log(el);
		}
		
		
	});
	
});

//function
//condition
//forloop

//ARRAY

//variables types
//string
//number
//object
//boolean
//null
//undefined


//Methord
//hide();
//show();
//toggle();
//animate();
//focus();
//children();
//parent();
//parents();
//siblings();
//addClass();
//removeClass();
//html();
//val();
//....etc

//example selector
//$("#moredetail")
//$(".border-r")
//$("button")
//$(".bannercont button")

//example events
//click
//doubleclick
//drag
//drop
//scroll
//mouseover
//mouseleave
//keydown
//keyup
//keypress



